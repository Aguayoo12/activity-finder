package com.activities;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiActividadesJwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
