package com.activities.DTO;

public class RolDTO {
	String rol;

	public RolDTO() {
		super();
	}
	
	public RolDTO(String rol) {
		super();
		this.rol = rol;
	}

	public String getRol() {
		return rol;
	}

	public void setRol(String rol) {
		this.rol = rol;
	}

	
	
}
