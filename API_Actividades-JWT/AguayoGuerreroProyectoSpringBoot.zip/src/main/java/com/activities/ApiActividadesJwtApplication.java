package com.activities;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiActividadesJwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiActividadesJwtApplication.class, args);
	}

}
